package com.stocks.stocksapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StocksApiMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
